package com.example.komishapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.Toast
import android.widget.Toast.LENGTH_SHORT
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import android.graphics.Color
import android.text.InputFilter


data class ChatMessage(
    val id: String = "",
    val message: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val senderId: String = ""
)

class MainActivity : AppCompatActivity() {

    // Declaring the EditText and Button variables.
    private lateinit var nameEditText: EditText
    private lateinit var enterButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Integrating the EditText and button variables with UI
        nameEditText = findViewById(R.id.NameEnter)
        enterButton = findViewById(R.id.enter)

        nameEditText.setTextColor(Color.BLACK)


        // If username is not empty, proceed to ChatActivity and pass the username along it.
        enterButton.setOnClickListener {
            val name = nameEditText.text.toString().trim()

            if (name.isNotEmpty()) {
                val intent = Intent(this, ChatActivity::class.java).apply {
                    putExtra("USER_NAME", name)
                }
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this, "Пожалуйста, введите ваше имя", Toast.LENGTH_SHORT).show()
            }
        }
    }
}


class ChatAdapter(private val messages: List<ChatMessage>) : RecyclerView.Adapter<ChatAdapter.ChatViewHolder>() {

    class ChatViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val senderTextView: TextView = view.findViewById(R.id.textViewSender)
        val messageTextView: TextView = view.findViewById(R.id.textViewMessage)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChatViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.chat_layout, parent, false)
        return ChatViewHolder(view)
    }

    override fun onBindViewHolder(holder: ChatViewHolder, position: Int) {
        val chatMessage = messages[position]
        holder.senderTextView.text = chatMessage.senderId
        holder.messageTextView.text = chatMessage.message
    }

    override fun getItemCount() = messages.size
}

class ChatActivity : AppCompatActivity() {

    // Declaring Necessary variables
    private lateinit var recyclerView: RecyclerView
    private lateinit var editTextMessage: EditText
    private lateinit var buttonSend: Button
    private lateinit var chatAdapter: ChatAdapter
    private val firestore = FirebaseFirestore.getInstance() // Getting Firestore instance.
    private val messagesCollection = firestore.collection("messages") // Our messages will be stored and fetched from "messages" collection
    private val messages = mutableListOf<ChatMessage>()
    private lateinit var userName: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        recyclerView = findViewById(R.id.recyclerView)
        editTextMessage = findViewById(R.id.editTextMessage)
        buttonSend = findViewById(R.id.buttonSend)

        editTextMessage.setTextColor(Color.BLACK)

        userName = intent.getStringExtra("USER_NAME") ?: "Anonymous"

        chatAdapter = ChatAdapter(messages)
        recyclerView.adapter = chatAdapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        fetchExistingMessages()

        buttonSend.setOnClickListener {
            val messageText = editTextMessage.text.toString()
            // Update the database with new messages.
            if (messageText.isNotEmpty()) {
                val message = ChatMessage(
                    id = messagesCollection.document().id,
                    message = messageText,
                    senderId = userName
                )
                messagesCollection.document(message.id).set(message)
                editTextMessage.text.clear()
            }
        }

        // Mock data for preview purposes
        messagesCollection.orderBy("timestamp", Query.Direction.ASCENDING)
            // SnapShot Listener listenes to any changes inside the collection, If there is any change, Update the recycler View. This helps chat update Realtime.
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    Toast.makeText(this, "Unable to get new Messages", LENGTH_SHORT)
                    return@addSnapshotListener
                }

                if (snapshot != null && !snapshot.isEmpty) {
                    messages.clear()
                    for (document in snapshot.documents) {
                        // Convert the data directly into class variable
                        val message = document.toObject(ChatMessage::class.java)
                        if (message != null) {
                            // Add the new message into the list of messages
                            messages.add(message)
                        }
                    }
                    // Update the RecyclerView.
                    chatAdapter.notifyDataSetChanged()
                    recyclerView.scrollToPosition(messages.size - 1)
                }
            }
    }

    private fun fetchExistingMessages() {
        // Getting any previous messages and ordering them with respect to time they got sent.
        messagesCollection.orderBy("timestamp", Query.Direction.ASCENDING)
            .get()
            .addOnSuccessListener { snapshot ->
                if (snapshot != null && !snapshot.isEmpty) {
                    messages.clear()
                    for (document in snapshot.documents) {
                        // Add all the messages into the list 'messages'
                        val message = document.toObject(ChatMessage::class.java)
                        if (message != null) {
                            messages.add(message)
                        }
                    }
                    // Update the RecyclerView with the messages.
                    chatAdapter.notifyDataSetChanged()
                    recyclerView.scrollToPosition(messages.size - 1)
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Unable to fetch Messages", LENGTH_SHORT)
            }
    }
}